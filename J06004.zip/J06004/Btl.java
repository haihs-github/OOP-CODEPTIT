package J06004;

public class Btl {
    private String ten;
    private int nhom;
    
    Btl(String ten, int nhom){
        this.ten = ten;
        this.nhom = nhom;
    }
    
    @Override
    public String toString(){
        return ten;
    }
    
    
}
